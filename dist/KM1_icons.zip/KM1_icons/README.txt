KM1 のアイコン / KM1 icons (KM1-ICO-001)

- 通常（regular）も塗り（filled）も、すべて KM1 が B 案で描いたもの（KM1-ICO-001 §8）。
- km1-icons.json の fluent の欄だけ、導入前と比べるための Fluent System Icons（Microsoft、MIT。LICENSE-Fluent.txt）の形（20px）を残している。
- 名前: km1_<名前>_<大きさ>_<regular|filled>.svg
All regular and filled shapes are KM1 B drawings; only the "fluent" field in km1-icons.json keeps Fluent System Icons (MIT, LICENSE-Fluent.txt) at 20px for before/after comparison.

中身 / Contents
- icons/    SVG（16・20・24px の Regular と Filled）、km1-icons.json、sprite-20.svg、Flutter 用の KM1Icons.ttf・km1_icons.dart・km1_icons_b.dart
          （Flutter に組み込むときは KM1 本体の km1_theme.dart（同じ版）も同じフォルダに置く。km1_widgets.dart は要らない）
          (Flutter also needs km1_theme.dart from the same KM1 version; km1_widgets.dart is not required)
- office/   PowerPoint・Word 用の SVG（20・24px）と PNG（256px）。「挿入 › 画像」で入れ、「グラフィックの塗りつぶし」で色を変える
- appicon/  KM1 のアプリアイコンとファビコン（web・android・ios・windows、flutter_launcher_icons.yaml）
